#include "stdafx.h"
#include "FTD2xx/ftd2xx.h"		//USB drivers


void LoadBitfile();
bool SendBitFile(FILE* file);
void HandEnterBytes();
